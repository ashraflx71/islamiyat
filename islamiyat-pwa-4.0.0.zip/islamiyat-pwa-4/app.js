"use strict";

/*
 * ISLAMIYAT PWA 4.0.0
 * Keeps the existing Supabase client in window.supabaseClient.
 * Quran offline copies are stored in IndexedDB, one Surah at a time.
 */
const Islamiyat = {
  version: "4.0.0",
  language: "ar",
  quranSurahs: [],
  quranRequestId: 0,
  dbPromise: null,

  translations: {
    ar: {
      brand:"إسلاميات", tagline:"نور العلم والذكر والهداية",
      nav:["الرئيسية","الأقسام","القرآن الكريم","عن المنصة"], languageButton:"English",
      menuLabel:"فتح القائمة", heroLabel:"بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ",
      heroTitle:"إسلاميات", heroSubtitle:"نور العلم والذكر والهداية",
      heroDescription:"رحلة إيمانية تجمع القرآن الكريم والسنة النبوية والأذكار والأدعية والعلوم الإسلامية في مكان واحد، بمصادر موثوقة وتجربة رقمية تليق بعظمة العلم النافع.",
      discover:"اكتشف أقسام المنصة", searchPlaceholder:"ابحث في أقسام إسلاميات...", searchLabel:"بحث",
      journey:"رحلتك إلى المعرفة", sectionsTitle:"أقسام المنصة",
      sectionsDescription:"أبواب متنوعة للعلم والعبادة والمعرفة الإسلامية.",
      categories:[
        ["القرآن الكريم","كتاب الله وتلاوة آياته وتدبر معانيه."],["الحديث النبوي","السنة النبوية والأحاديث ومصادرها."],
        ["الأذكار","أذكار الصباح والمساء والأذكار اليومية."],["الأدعية","الأدعية المأثورة من القرآن والسنة."],
        ["التفسير","تفسير الآيات وفهم معاني القرآن الكريم."],["السيرة النبوية","سيرة الرسول ﷺ ومواقفه ودروسه العظيمة."],
        ["الفقه الإسلامي","العبادات والمعاملات والأحكام الشرعية."],["المقالات الإسلامية","موضوعات نافعة ومعرفة إسلامية موثقة."],
        ["المكتبة الإسلامية","الكتب والمراجع والمصادر العلمية."]
      ],
      quranEyebrow:"كلام الله تعالى",quranTitle:"القرآن الكريم",selectSurah:"اختر السورة",
      verses:"آية",juz:"الجزء",page:"الصفحة",sajda:"موضع سجدة",
      loadingSurahs:"جارٍ تحميل سور القرآن الكريم...",loadingVerses:"جارٍ تحميل الآيات...",
      loadedVerses:"تم تحميل الآيات بنجاح.",noSurahs:"لا توجد سور متاحة في قاعدة البيانات.",
      noVerses:"لا توجد آيات مسجلة لهذه السورة.",quranError:"تعذر تحميل القرآن الكريم. تحقق من الاتصال وصلاحيات القراءة.",
      databaseError:"تعذر الاتصال بقاعدة البيانات.",aboutEyebrow:"رسالتنا",
      aboutTitle:"العلم النافع والأمانة",aboutText:"نسعى إلى تقديم محتوى إسلامي موثوق، يجمع بين صحة المعلومة وسهولة الوصول واحترام عقل الزائر ووقته.",
      values:[["المصداقية","الرجوع إلى المصادر الموثوقة."],["الأمانة","الدقة في نقل النصوص الشرعية."],["العلم النافع","معرفة يسهل الوصول إليها."]],
      footerTagline:"نور العلم والذكر والهداية",footerPrayer:"نسأل الله أن يجعل هذا العمل خالصًا لوجهه الكريم وأن ينفع به عباده.",
      footerLinks:["الرئيسية","الأقسام","عن المنصة"],backToTop:"العودة إلى الأعلى",
      noResults:"لم نعثر على أقسام تطابق بحثك.",download:"تنزيل السورة المحددة",
      downloading:"جارٍ تنزيل السورة وحفظها...",saved:"تم حفظ السورة على جهازك ويمكن قراءتها دون إنترنت.",
      offlineLoaded:"تم عرض السورة المحفوظة دون اتصال.",savedList:"السور المحفوظة",
      noSaved:"لا توجد سور محفوظة بعد.",delete:"حذف",deleted:"تم حذف النسخة المحفوظة.",
      downloadError:"تعذر حفظ السورة. تحقق من الاتصال ومساحة التخزين.",
      offlineMissing:"هذه السورة غير محفوظة على جهازك. اتصل بالإنترنت لتنزيلها."
    },
    en: {
      brand:"Islamiyat",tagline:"The Light of Knowledge, Remembrance and Guidance",
      nav:["Home","Sections","The Holy Quran","About"],languageButton:"العربية",
      menuLabel:"Open menu",heroLabel:"IN THE NAME OF ALLAH, THE MOST MERCIFUL",
      heroTitle:"Islamiyat",heroSubtitle:"The Light of Knowledge, Remembrance and Guidance",
      heroDescription:"A spiritual journey bringing together the Holy Quran, Prophetic Sunnah, remembrance, supplications and Islamic knowledge in one trusted place.",
      discover:"Explore Our Sections",searchPlaceholder:"Search Islamiyat sections...",searchLabel:"Search",
      journey:"Your Journey to Knowledge",sectionsTitle:"Our Sections",
      sectionsDescription:"A variety of paths to Islamic knowledge and worship.",
      categories:[
        ["The Holy Quran","The Book of Allah, its recitation and reflection."],["Prophetic Hadith","The Sunnah, Hadith and their sources."],
        ["Daily Remembrance","Morning, evening and daily supplications."],["Supplications","Authentic supplications from the Quran and Sunnah."],
        ["Quran Interpretation","Understanding the meanings of Quranic verses."],["Prophet's Biography","The life and teachings of Prophet Muhammad ﷺ."],
        ["Islamic Jurisprudence","Worship, transactions and Islamic rulings."],["Islamic Articles","Useful and documented Islamic knowledge."],
        ["Islamic Library","Islamic books, references and resources."]
      ],
      quranEyebrow:"The Words of Allah",quranTitle:"The Holy Quran",selectSurah:"Select a Surah",
      verses:"Verses",juz:"Juz",page:"Page",sajda:"Prostration verse",
      loadingSurahs:"Loading Quran chapters...",loadingVerses:"Loading verses...",
      loadedVerses:"Verses loaded successfully.",noSurahs:"No Surahs available in the database.",
      noVerses:"No verses found for this Surah.",quranError:"Unable to load the Quran. Check connection and read permissions.",
      databaseError:"Unable to connect to the database.",aboutEyebrow:"Our Mission",
      aboutTitle:"Beneficial Knowledge and Integrity",aboutText:"We aim to provide reliable Islamic content through accurate information, easy access and respect for our visitors.",
      values:[["Credibility","Relying on trusted sources."],["Integrity","Accuracy in transmitting religious texts."],["Beneficial Knowledge","Knowledge made easy to access."]],
      footerTagline:"The Light of Knowledge, Remembrance and Guidance",footerPrayer:"May Allah make this work sincerely for His sake and benefit His servants.",
      footerLinks:["Home","Sections","About"],backToTop:"Back to top",
      noResults:"No sections match your search.",download:"Download selected Surah",
      downloading:"Downloading and saving the Surah...",saved:"Surah saved on this device for offline reading.",
      offlineLoaded:"Showing the saved Surah offline.",savedList:"Saved Surahs",
      noSaved:"No saved Surahs yet.",delete:"Delete",deleted:"Saved copy deleted.",
      downloadError:"Could not save the Surah. Check connection and storage space.",
      offlineMissing:"This Surah is not saved on this device. Connect to download it."
    }
  },

  init() {
    this.updateYear();
    this.setupNavigation();
    this.setupSearch();
    this.setupLanguage();
    this.setupBackToTop();
    this.setupMobileMenu();
    this.setupOfflineControls();
    this.applyLanguage(this.getSavedLanguage());
    this.loadQuran();
    console.log("Islamiyat initialized:", this.version);
  },

  get t(){ return this.translations[this.language]; },

  updateYear() {
    const el=document.getElementById("current-year");
    if(el) el.textContent=String(new Date().getFullYear());
  },

  getSavedLanguage() {
    try { return localStorage.getItem("islamiyat-language")==="en"?"en":"ar"; }
    catch { return "ar"; }
  },

  setupLanguage() {
    const button=document.getElementById("language-button");
    if(!button)return;
    button.addEventListener("click",()=>{
      const next=this.language==="ar"?"en":"ar";
      this.applyLanguage(next);
      try{localStorage.setItem("islamiyat-language",next);}catch{}
    });
  },

  applyLanguage(language) {
    this.language=language==="en"?"en":"ar";
    const t=this.t, lang=this.language;
    document.documentElement.lang=lang;
    document.documentElement.dir=lang==="ar"?"rtl":"ltr";
    document.documentElement.style.setProperty("font-family",'"Tajawal",sans-serif');
    document.title=lang==="ar"?"إسلاميات | نور العلم والذكر والهداية":"Islamiyat | Knowledge, Remembrance and Guidance";
    this.setText(".brand-text strong",t.brand);
    this.setText(".brand-text small",t.tagline);
    document.querySelectorAll(".main-nav a").forEach((el,i)=>{if(t.nav[i])el.textContent=t.nav[i];});
    const lb=document.getElementById("language-button");if(lb)lb.textContent=t.languageButton;
    const mb=document.getElementById("menu-button");if(mb)mb.setAttribute("aria-label",t.menuLabel);
    this.setText(".hero-label",t.heroLabel);this.setText(".hero-content h1",t.heroTitle);
    this.setText(".hero-content h2",t.heroSubtitle);this.setText(".hero-content > p",t.heroDescription);
    const discover=document.querySelector(".primary-button");
    if(discover){const arrow=document.createElement("span");arrow.textContent=lang==="ar"?"←":"→";discover.replaceChildren(document.createTextNode(t.discover+" "),arrow);}
    const search=document.getElementById("site-search");if(search){search.placeholder=t.searchPlaceholder;search.setAttribute("aria-label",t.searchLabel);}
    this.setText(".sections-section .section-eyebrow",t.journey);
    this.setText(".sections-section .section-heading h2",t.sectionsTitle);
    this.setText(".sections-section .section-heading p",t.sectionsDescription);
    document.querySelectorAll(".category-card").forEach((card,i)=>{if(!t.categories[i])return;const h=card.querySelector("h3"),p=card.querySelector("p");if(h)h.textContent=t.categories[i][0];if(p)p.textContent=t.categories[i][1];});
    const sectionData=[
      ["#quran",t.quranEyebrow,t.quranTitle],["#hadith",lang==="ar"?"هدي النبي ﷺ":"The Prophet's Guidance ﷺ",lang==="ar"?"السنة النبوية":"Prophetic Sunnah"],
      ["#adhkar",lang==="ar"?"طمأنينة القلب":"Peace of Heart",lang==="ar"?"الأذكار":"Daily Remembrance"],
      ["#dua",lang==="ar"?"الدعاء عبادة":"Supplication is Worship",lang==="ar"?"الأدعية":"Supplications"],
      ["#tafsir",lang==="ar"?"تدبر وفهم":"Reflection and Understanding",lang==="ar"?"التفسير":"Quran Interpretation"],
      ["#seerah",lang==="ar"?"السيرة العطرة":"The Blessed Biography",lang==="ar"?"السيرة النبوية":"Prophet's Biography"],
      ["#fiqh",lang==="ar"?"فقه وعبادة":"Islamic Law and Worship",lang==="ar"?"الفقه الإسلامي":"Islamic Jurisprudence"],
      ["#articles",lang==="ar"?"علم ومعرفة":"Knowledge and Learning",lang==="ar"?"المقالات الإسلامية":"Islamic Articles"],
      ["#library",lang==="ar"?"كنوز المعرفة":"Treasures of Knowledge",lang==="ar"?"المكتبة الإسلامية":"Islamic Library"]
    ];
    sectionData.forEach(([selector,eyebrow,title])=>{const s=document.querySelector(selector);if(!s)return;const e=s.querySelector(".section-eyebrow"),h=s.querySelector("h2");if(e)e.textContent=eyebrow;if(h)h.textContent=title;});
    this.setText(".about-section .section-eyebrow",t.aboutEyebrow);this.setText(".about-section h2",t.aboutTitle);this.setText(".about-section > p",t.aboutText);
    document.querySelectorAll(".value-item").forEach((item,i)=>{if(!t.values[i])return;const h=item.querySelector("h3"),p=item.querySelector("p");if(h)h.textContent=t.values[i][0];if(p)p.textContent=t.values[i][1];});
    this.setText(".site-footer h2",t.brand);this.setText(".site-footer > p:not(.copyright):not(.footer-prayer)",t.footerTagline);
    this.setText(".footer-prayer",t.footerPrayer);
    document.querySelectorAll(".footer-links a").forEach((el,i)=>{if(t.footerLinks[i])el.textContent=t.footerLinks[i];});
    const top=document.getElementById("back-to-top");if(top)top.setAttribute("aria-label",t.backToTop);
    const download=document.getElementById("download-surah");if(download)download.textContent=t.download;
    this.updateSearch();
    if(this.quranSurahs.length){const select=document.getElementById("quran-surah-select");const selected=select?Number(select.value):Number(this.quranSurahs[0].surah_number);this.renderQuranBrowser(document.getElementById("quran-content"),this.quranSurahs,selected);}
    this.refreshOfflineList();
  },

  setText(selector,value){document.querySelectorAll(selector).forEach(el=>{el.textContent=value;});},

  setupNavigation() {
    document.querySelectorAll('nav a[href^="#"]').forEach(link=>link.addEventListener("click",event=>{
      const target=document.querySelector(link.getAttribute("href"));
      if(target){event.preventDefault();target.scrollIntoView({behavior:"smooth",block:"start"});this.closeMobileMenu();}
    }));
  },

  setupMobileMenu() {
    const button=document.getElementById("menu-button"),nav=document.querySelector(".main-nav");
    if(!button||!nav)return;
    button.addEventListener("click",()=>{const open=nav.classList.toggle("is-open");button.setAttribute("aria-expanded",String(open));button.setAttribute("aria-label",open?(this.language==="ar"?"إغلاق القائمة":"Close menu"):this.t.menuLabel);});
    document.addEventListener("click",event=>{if(!nav.contains(event.target)&&!button.contains(event.target))this.closeMobileMenu();});
    document.addEventListener("keydown",event=>{if(event.key==="Escape")this.closeMobileMenu();});
  },

  closeMobileMenu() {
    const nav=document.querySelector(".main-nav"),button=document.getElementById("menu-button");
    if(!nav||!button)return;nav.classList.remove("is-open");button.setAttribute("aria-expanded","false");button.setAttribute("aria-label",this.t.menuLabel);
  },

  setupSearch() {
    const input=document.getElementById("site-search");if(input)input.addEventListener("input",()=>this.updateSearch());
  },

  updateSearch() {
    const input=document.getElementById("site-search"),cards=document.querySelectorAll(".category-card");if(!input||!cards.length)return;
    const query=input.value.trim().toLocaleLowerCase();let count=0;
    cards.forEach(card=>{const match=card.textContent.toLocaleLowerCase().includes(query);card.hidden=!match;if(match)count++;});
    let msg=document.getElementById("search-no-results");
    if(!msg){msg=document.createElement("p");msg.id="search-no-results";msg.className="search-no-results";document.querySelector(".categories-grid")?.insertAdjacentElement("afterend",msg);}
    if(msg){msg.textContent=this.t.noResults;msg.hidden=!query||count>0;}
  },

  setupBackToTop() {
    const button=document.getElementById("back-to-top");if(!button)return;
    const update=()=>button.classList.toggle("is-visible",window.scrollY>350);
    window.addEventListener("scroll",update,{passive:true});
    button.addEventListener("click",()=>window.scrollTo({top:0,behavior:"smooth"}));update();
  },

  async openDB() {
    if(this.dbPromise)return this.dbPromise;
    this.dbPromise=new Promise((resolve,reject)=>{
      if(!("indexedDB" in window)){reject(new Error("IndexedDB unavailable"));return;}
      const request=indexedDB.open("islamiyat-quran-offline",1);
      request.onupgradeneeded=()=>{const db=request.result;if(!db.objectStoreNames.contains("surahs"))db.createObjectStore("surahs",{keyPath:"surah_number"});};
      request.onsuccess=()=>resolve(request.result);
      request.onerror=()=>reject(request.error||new Error("Database open failed"));
    });
    return this.dbPromise;
  },

  async storeOfflineSurah(surahNumber,verses) {
    const db=await this.openDB();
    return new Promise((resolve,reject)=>{
      const tx=db.transaction("surahs","readwrite");
      tx.objectStore("surahs").put({surah_number:Number(surahNumber),verses,saved_at:new Date().toISOString(),count:verses.length});
      tx.oncomplete=()=>resolve(true);tx.onerror=()=>reject(tx.error||new Error("Save failed"));tx.onabort=()=>reject(tx.error||new Error("Save aborted"));
    });
  },

  async getOfflineSurah(surahNumber) {
    const db=await this.openDB();
    return new Promise((resolve,reject)=>{
      const tx=db.transaction("surahs","readonly"),req=tx.objectStore("surahs").get(Number(surahNumber));
      req.onsuccess=()=>resolve(req.result||null);req.onerror=()=>reject(req.error);
    });
  },

  async getAllOfflineSurahs() {
    const db=await this.openDB();
    return new Promise((resolve,reject)=>{
      const tx=db.transaction("surahs","readonly"),req=tx.objectStore("surahs").getAll();
      req.onsuccess=()=>resolve(req.result||[]);req.onerror=()=>reject(req.error);
    });
  },

  async deleteOfflineSurah(surahNumber) {
    const db=await this.openDB();
    return new Promise((resolve,reject)=>{
      const tx=db.transaction("surahs","readwrite");tx.objectStore("surahs").delete(Number(surahNumber));
      tx.oncomplete=()=>resolve(true);tx.onerror=()=>reject(tx.error);
    });
  },

  setupOfflineControls() {
    const download=document.getElementById("download-surah"),list=document.getElementById("show-offline");
    if(download)download.addEventListener("click",()=>this.downloadSelectedSurah());
    if(list)list.addEventListener("click",()=>this.refreshOfflineList(true));
  },

  async downloadSelectedSurah() {
    const select=document.getElementById("quran-surah-select"),status=document.getElementById("offline-status"),button=document.getElementById("download-surah");
    if(!select||!status||!button)return;
    const number=Number(select.value);if(!number)return;
    button.disabled=true;status.textContent=this.t.downloading;
    try{
      const cached=await this.getOfflineSurah(number);
      if(cached&&Array.isArray(cached.verses)&&cached.verses.length){status.textContent=this.t.saved;return;}
      if(!navigator.onLine){status.textContent=this.t.offlineMissing;return;}
      const client=window.supabaseClient;if(!client)throw new Error("Supabase client missing");
      const {data,error}=await client.from("quran_verses")
        .select("surah_number,ayah_number,text_uthmani,juz_number,page_number,hizb_quarter,sajda")
        .eq("surah_number",number).order("ayah_number",{ascending:true});
      if(error)throw error;
      const expected=this.quranSurahs.find(s=>Number(s.surah_number)===number)?.ayah_count;
      if(!Array.isArray(data)||data.length===0||(Number.isFinite(Number(expected))&&data.length!==Number(expected))||data.some(v=>!v.text_uthmani||!Number.isFinite(Number(v.ayah_number))))throw new Error("Incomplete or invalid Surah data");
      await this.storeOfflineSurah(number,data);
      const verify=await this.getOfflineSurah(number);
      if(!verify||verify.verses.length!==data.length)throw new Error("Offline verification failed");
      status.textContent=this.t.saved;await this.refreshOfflineList();
    }catch(error){console.error("Offline Quran save error:",error);status.textContent=this.t.downloadError;}
    finally{button.disabled=false;}
  },

  async refreshOfflineList(show=false) {
    const holder=document.getElementById("offline-list");if(!holder)return;
    try{
      const saved=await this.getAllOfflineSurahs();holder.replaceChildren();
      if(!saved.length){holder.textContent=this.t.noSaved;holder.hidden=!show;return;}
      saved.sort((a,b)=>a.surah_number-b.surah_number);
      const heading=document.createElement("strong");heading.textContent=this.t.savedList;holder.appendChild(heading);
      saved.forEach(item=>{
        const surah=this.quranSurahs.find(s=>Number(s.surah_number)===Number(item.surah_number));
        const row=document.createElement("div");row.className="offline-row";
        const name=document.createElement("span");name.textContent=`${item.surah_number}. ${surah?.name_ar||""} (${item.count||item.verses.length})`;
        const del=document.createElement("button");del.type="button";del.textContent=this.t.delete;
        del.addEventListener("click",async()=>{await this.deleteOfflineSurah(item.surah_number);this.setOfflineStatus(this.t.deleted);await this.refreshOfflineList(true);});
        row.append(name,del);holder.appendChild(row);
      });
      holder.hidden=!show;
    }catch(error){console.warn("Offline list unavailable:",error);holder.hidden=true;}
  },

  setOfflineStatus(message){const el=document.getElementById("offline-status");if(el)el.textContent=message;},

  async loadQuran() {
    const container=document.getElementById("quran-content");if(!container)return;
    const client=window.supabaseClient;
    if(!client){container.textContent=this.t.databaseError;console.error("window.supabaseClient is not configured.");return;}
    container.textContent=this.t.loadingSurahs;
    try{
      const {data,error}=await client.from("quran_surahs")
        .select("surah_number,name_ar,revelation_type,ayah_count")
        .order("surah_number",{ascending:true});
      if(error)throw error;
      if(!Array.isArray(data)||!data.length){container.textContent=this.t.noSurahs;return;}
      this.quranSurahs=data;
      this.renderQuranBrowser(container,data,data[0].surah_number);
      const download=document.getElementById("download-surah");if(download)download.disabled=false;
      await this.refreshOfflineList();
    }catch(error){console.error("Quran Surahs error:",error);container.textContent=this.t.quranError;}
  },

  renderQuranBrowser(container,surahs,selectedNumber) {
    if(!container)return;
    const t=this.t;container.replaceChildren();
    const wrapper=document.createElement("div");wrapper.className="quran-browser";
    const label=document.createElement("label");label.htmlFor="quran-surah-select";label.textContent=t.selectSurah;
    const select=document.createElement("select");select.id="quran-surah-select";select.className="quran-surah-select";
    surahs.forEach(surah=>{
      const option=document.createElement("option");option.value=String(surah.surah_number);
      option.textContent=`${surah.surah_number}. ${surah.name_ar} (${surah.ayah_count} ${t.verses})`;
      option.selected=Number(surah.surah_number)===Number(selectedNumber);select.appendChild(option);
    });
    const details=document.createElement("div");details.className="quran-surah-details";
    const status=document.createElement("p");status.className="quran-status";
    const verses=document.createElement("div");verses.className="quran-verses";
    wrapper.append(label,select,details,status,verses);container.appendChild(wrapper);
    select.addEventListener("change",()=>this.loadSurahVerses(Number(select.value),details,verses,status));
    this.loadSurahVerses(Number(select.value),details,verses,status);
  },

  async loadSurahVerses(surahNumber,details,verses,status) {
    const requestId=++this.quranRequestId;
    const surah=this.quranSurahs.find(s=>Number(s.surah_number)===Number(surahNumber));
    if(!surah){status.textContent=this.t.noSurahs;return;}
    details.textContent=`${surah.name_ar} - ${surah.ayah_count} ${this.t.verses}`;
    verses.replaceChildren();status.textContent=this.t.loadingVerses;
    try{
      let data=null;
      if(!navigator.onLine){
        const cached=await this.getOfflineSurah(surahNumber);
        if(cached)data=cached.verses;
        else{if(requestId===this.quranRequestId)status.textContent=this.t.offlineMissing;return;}
      }else{
        const client=window.supabaseClient;
        if(!client)throw new Error("Supabase client missing");
        const {data:remote,error}=await client.from("quran_verses")
          .select("surah_number,ayah_number,text_uthmani,juz_number,page_number,hizb_quarter,sajda")
          .eq("surah_number",surahNumber).order("ayah_number",{ascending:true});
        if(error)throw error;
        data=remote;
      }
      if(requestId!==this.quranRequestId)return;
      if(!Array.isArray(data)||!data.length){status.textContent=this.t.noVerses;return;}
      this.renderVerses(data,verses);
      status.textContent=!navigator.onLine?this.t.offlineLoaded:`${this.t.loadedVerses} (${data.length})`;
    }catch(error){
      if(requestId!==this.quranRequestId)return;
      console.error("Quran verses error:",error);
      try{
        const cached=await this.getOfflineSurah(surahNumber);
        if(requestId===this.quranRequestId&&cached?.verses?.length){this.renderVerses(cached.verses,verses);status.textContent=this.t.offlineLoaded;return;}
      }catch{}
      status.textContent=this.t.quranError;
    }
  },

  renderVerses(data,container) {
    const fragment=document.createDocumentFragment(),t=this.t;
    data.forEach(verse=>{
      const article=document.createElement("article");article.className="quran-verse-item";
      const text=document.createElement("p");text.className="quran-verse-text";text.dir="rtl";text.lang="ar";
      text.textContent=`${verse.text_uthmani} ﴿${verse.ayah_number}﴾`;
      const meta=document.createElement("div");meta.className="quran-verse-metadata";
      meta.textContent=`${t.juz}: ${verse.juz_number??"—"} | ${t.page}: ${verse.page_number??"—"}`;
      article.append(text,meta);
      if(verse.sajda===true){const sajda=document.createElement("span");sajda.className="quran-sajda";sajda.textContent=t.sajda;article.appendChild(sajda);}
      fragment.appendChild(article);
    });
    container.replaceChildren(fragment);
  }
};

document.addEventListener("DOMContentLoaded",()=>Islamiyat.init());
window.Islamiyat=Islamiyat;
