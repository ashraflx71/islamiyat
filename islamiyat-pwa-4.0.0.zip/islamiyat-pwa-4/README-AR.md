# إسلاميات PWA 4.0.0

## الملفات
- `index.html`
- `style.css`
- `app.js`
- `manifest.json`
- `service-worker.js`
- `icons/icon.svg`

## مهم قبل النشر
1. احتفظ بملف `supabase-config.js` الحالي كما هو، وضعه بجوار `index.html`.
2. يجب أن يعرّف الملف الحالي `window.supabaseClient` باستخدام `createClient` من مكتبة Supabase وبالمفتاح العام Publishable فقط.
3. لا ترفع مفتاح `service_role` إلى GitHub أو إلى ملفات المتصفح.
4. ارفع الملفات على استضافة HTTPS. لن يعمل Service Worker من `file://`.
5. تنزيل السورة يحتاج اتصالًا بالإنترنت أول مرة. بعد التحقق من اكتمال بياناتها، تحفظ في IndexedDB على الجهاز نفسه.
6. لا يتم تنزيل القرآن كاملًا تلقائيًا؛ المستخدم يختار السور التي يريد حفظها.

## تنبيه تكاملي
يفترض التطبيق وجود الجدولين `quran_surahs` و`quran_verses` والأعمدة التي يستخدمها الكود. لم يتضمن هذا الإصدار أي SQL أو تغييرًا لسياسات RLS.
